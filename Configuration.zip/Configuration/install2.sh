mkdir ~/mine
cd ~/Downloads
wget https://github.com/Alfa512/Test/raw/master/ClaymoreDualUbuntu.tar
tar -Jxvf ClaymoreDualUbuntu.tar -C ~/mine
cd ~/mine/ClaymoreDualUbuntu
./start_eth+dcr.bash &
