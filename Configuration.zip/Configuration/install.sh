sudo apt-get install openssh-server;
sudo apt-get dist-upgrade;
mkdir ~/Downloads
cd ~/Downloads
wget https://www2.ati.com/drivers/linux/ubuntu/amdgpu-pro-17.30-465504.tar.xz
tar -Jxvf amdgpu-pro-17.30-465504.tar.xz
cd amdgpu-pro-17.30-465504
./amdgpu-pro-install -y
sudo usermod -a -G video $LOGNAME
sudo reboot