export GPU_FORCE_64BIT_PTR 0
export GPU_MAX_HEAP_SIZE 100
export GPU_USE_SYNC_OBJECTS 1
export GPU_MAX_ALLOC_PERCENT 100
export GPU_SINGLE_ALLOC_PERCENT 100

./ethdcrminer64 -ethi 2 -allpools 1 -mode 0 -dcri 42 -ftime 10 -r 60 -tt -60,-60 